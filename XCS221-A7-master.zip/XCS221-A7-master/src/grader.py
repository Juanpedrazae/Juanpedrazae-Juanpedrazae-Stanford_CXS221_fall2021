#!/usr/bin/env python3
import unittest, random, sys, copy, argparse, inspect, collections, os, pickle, gzip
from graderUtil import graded, CourseTestRunner, GradedTestCase

from logic import *
import nlparser

# Import student submission
import submission

#############################################
# HELPER FUNCTIONS FOR CREATING TEST INPUTS #
#############################################

class TestCase_A7(GradedTestCase):
  # name: name of this formula (used to load the models)
  # predForm: the formula predicted in the submission
  # preconditionForm: only consider models such that preconditionForm is true
  def checkFormula(self, name, predForm, preconditionForm=None):
    filename = os.path.join('models', name + '.pklz')
    objects, targetModels = pickle.load(gzip.open(filename))
    # If preconditionion exists, change the formula to
    preconditionPredForm = And(preconditionForm, predForm) if preconditionForm else predForm
    predModels = performModelChecking([preconditionPredForm], findAll=True, objects=objects)
    ok = True
    def hashkey(model): return tuple(sorted(str(atom) for atom in model))
    targetModelSet = set(hashkey(model) for model in targetModels)
    predModelSet = set(hashkey(model) for model in predModels)
    for model in targetModels:
      self.assertTrue(hashkey(model) in predModelSet, msg=f'Your formula ({predForm}) says the following model is FALSE, but it should be TRUE:\n{printModel(model, ret=True)}')
    for model in predModels:
      self.assertTrue(hashkey(model) in targetModelSet, msg=f'Your formula ({predForm}) says the following model is TRUE, but it should be FALSE:\n{printModel(model, ret=True)}')
    print(f'You matched the {len(targetModels)} models')
    print(f'Example model: {rstr(random.choice(targetModels))}')

  # name: name of this formula set (used to load the models)
  # predForms: formulas predicted in the submission
  # predQuery: query formula predicted in the submission
  def check(self, part, name, numForms, predictionFunc):
    predForms, predQuery = predictionFunc()
    if len(predForms) < numForms:
      grader.fail("Wanted %d formulas, but got %d formulas:" % (numForms, len(predForms)))
      for form in predForms: print(('-', form))
      return
    if part == 'all':
      self.checkFormula(name + '-all', AndList(predForms))
    elif part == 'run':
      # Actually run it on a knowledge base
      #kb = createResolutionKB()  # Too slow!
      kb = createModelCheckingKB()

      # Need to tell the KB about the objects to do model checking
      filename = os.path.join('models', name + '-all.pklz')
      objects, targetModels = pickle.load(gzip.open(filename))
      for obj in objects:
        kb.tell(Atom('Object', obj))

      # Add the formulas
      for predForm in predForms:
        response = kb.tell(predForm)
        showKBResponse(response)
        self.assertEqual(CONTINGENT, response.status)
      response = kb.ask(predQuery)
      showKBResponse(response)

    else:  # Check the part-th formula
      self.checkFormula(name + '-' + str(part), predForms[part])

  def getTopDerivation(self, sentence, languageProcessor, grammar):
    # Return (action, formula)
    # - action is either |tell| or |ask|
    # - formula is a logical form
    print()
    print(('>>>', sentence))
    utterance = nlparser.Utterance(sentence, languageProcessor)
    print(('Utterance:', utterance))
    derivations = nlparser.parseUtterance(utterance, grammar, verbose=0)
    if not derivations:
      raise Exception('Error: Parsing failed. (0 derivations)')
    return derivations[0].form

  def compareExtraCreditKnowledgeBase(self, examples, ruleCreator):
    # Test the logical forms by querying the knowledge base.
    kb = createModelCheckingKB()
    #kb = createResolutionKB()
    languageProcessor = nlparser.createBaseLanguageProcessor()
    # Need to tell kb about objects
    for obj in nlparser.BASE_OBJECTS:
      kb.tell(Atom('Object', obj.lower()))

    # Parse!
    grammar = nlparser.createBaseEnglishGrammar() + [ruleCreator()]
    for sentence, expectedResult in examples:
      mode, formula = self.getTopDerivation(sentence, languageProcessor, grammar)
      print(('The parser returns:', (mode, formula)))
      self.assertEqual(expectedResult[0], mode)
      if mode == 'tell':  response = kb.tell(formula)
      if mode == 'ask':   response = kb.ask(formula)
      print(('Knowledge base returns:', response))
      self.assertEqual(expectedResult[1], response.status)

#########
# TESTS #
#########
class Test_1a(TestCase_A7):
  @graded()
  def test_0(self):
    """1a-0-basic:  Test formula 1a implementation"""
    self.checkFormula('1a', submission.formula1a())
class Test_1b(TestCase_A7):
  @graded()
  def test_0(self):
    """1b-0-basic:  Test formula 1b implementation"""
    self.checkFormula('1b', submission.formula1b())
class Test_1c(TestCase_A7):
  @graded()
  def test_0(self):
    """1c-0-basic:  Test formula 1c implementation"""
    self.checkFormula('1c', submission.formula1c())
class Test_2a(TestCase_A7):
  @graded()
  def test_0(self):
    """2a-0-basic:  Test formula 2a implementation"""
    formula2a_precondition = AntiReflexive('Mother')
    self.checkFormula('2a', submission.formula2a(), formula2a_precondition)
class Test_2b(TestCase_A7):
  @graded()
  def test_0(self):
    """2b-0-basic:  Test formula 2b implementation"""
    formula2b_precondition = AntiReflexive('Child')
    self.checkFormula('2b', submission.formula2b(), formula2b_precondition)
class Test_2c(TestCase_A7):
  @graded()
  def test_0(self):
    """2c-0-basic:  Test formula 2c implementation"""
    formula2c_precondition = AntiReflexive('Child')
    self.checkFormula('2c', submission.formula2c(), formula2c_precondition)
class Test_2d(TestCase_A7):
  @graded()
  def test_0(self):
    """2d-0-basic:  Test formula 2d implementation"""
    formula2d_precondition = AntiReflexive('Parent')
    self.checkFormula('2d', submission.formula2d(), formula2d_precondition)
class Test_3a(TestCase_A7):
  @graded(timeout=10000)
  def test_0(self):
    """3a-0-basic:  test implementation of statement 0 for 3a"""
    self.check(0, '3a', 6, submission.liar)

  @graded(timeout=10000)
  def test_1(self):
    """3a-1-basic:  test implementation of statement 1 for 3a"""
    self.check(1, '3a', 6, submission.liar)

  @graded(timeout=10000)
  def test_2(self):
    """3a-2-basic:  test implementation of statement 2 for 3a"""
    self.check(2, '3a', 6, submission.liar)

  @graded(timeout=10000)
  def test_3(self):
    """3a-3-basic:  test implementation of statement 3 for 3a"""
    self.check(3, '3a', 6, submission.liar)

  @graded(timeout=10000)
  def test_4(self):
    """3a-4-basic:  test implementation of statement 4 for 3a"""
    self.check(4, '3a', 6, submission.liar)

  @graded(timeout=10000)
  def test_5(self):
    """3a-5-basic:  test implementation of statement 5 for 3a"""
    self.check(5, '3a', 6, submission.liar)

  @graded(timeout=10000)
  def test_all(self):
    """3a-all-basic:  test implementation of all for 3a"""
    self.check('all', '3a', 6, submission.liar)

  @graded(timeout=10000)
  def test_run(self):
    """3a-run-basic:  test implementation of run for 3a"""
    self.check('run', '3a', 6, submission.liar)
class Test_5a(TestCase_A7):
  @graded(timeout=10000)
  def test_0(self):
    """5a-0-basic:  test implementation of statement 0 for 5a"""
    self.check(0, '5a', 6, submission.ints)

  @graded(timeout=10000)
  def test_1(self):
    """5a-1-basic:  test implementation of statement 1 for 5a"""
    self.check(1, '5a', 6, submission.ints)

  @graded(timeout=10000)
  def test_2(self):
    """5a-2-basic:  test implementation of statement 2 for 5a"""
    self.check(2, '5a', 6, submission.ints)

  @graded(timeout=10000)
  def test_3(self):
    """5a-3-basic:  test implementation of statement 3 for 5a"""
    self.check(3, '5a', 6, submission.ints)

  @graded(timeout=10000)
  def test_4(self):
    """5a-4-basic:  test implementation of statement 4 for 5a"""
    self.check(4, '5a', 6, submission.ints)

  @graded(timeout=10000)
  def test_5(self):
    """5a-5-basic:  test implementation of statement 5 for 5a"""
    self.check(5, '5a', 6, submission.ints)

  @graded(timeout=10000)
  def test_all(self):
    """5a-all-basic:  test implementation of all for 5a"""
    self.check('all', '5a', 6, submission.ints)

  @graded(timeout=10000)
  def test_run(self):
    """5a-run-basic:  test implementation of run for 5a"""
    self.check('run', '5a', 6, submission.ints)
class Test_6a(TestCase_A7):
  @graded(timeout=60, is_extra_credit=True)
  def test_0(self):
    """6a-0-basic:  Check basic behavior of rule"""
    examples = [
        ('Every person likes some cat.', ('tell', CONTINGENT)),
        ('Every cat is a mammal.', ('tell', CONTINGENT)),
        ('Every person likes some mammal?', ('ask', ENTAILMENT)),
    ]
    self.compareExtraCreditKnowledgeBase(examples, submission.createRule1)

  @graded(timeout=60, is_extra_credit=True)
  def test_1(self):
    """6a-1-basic:  Check basic behavior of rule"""
    examples = [
        ('Every person likes some cat.', ('tell', CONTINGENT)),
        ('Every tabby is a cat.', ('tell', CONTINGENT)),
        ('Every person likes some tabby?', ('ask', CONTINGENT)),
    ]
    self.compareExtraCreditKnowledgeBase(examples, submission.createRule1)

  @graded(timeout=60, is_extra_credit=True)
  def test_2(self):
    """6a-2-basic:  Check basic behavior of rule"""
    examples = [
        ('Every person likes some cat.', ('tell', CONTINGENT)),
        ('Every person is a mammal.', ('tell', CONTINGENT)),
        ('Every mammal likes some cat?', ('ask', CONTINGENT)),
    ]
    self.compareExtraCreditKnowledgeBase(examples, submission.createRule1)

  @graded(timeout=60, is_extra_credit=True)
  def test_3(self):
    """6a-3-basic:  Check basic behavior of rule"""
    examples = [
        ('Every person likes some cat.', ('tell', CONTINGENT)),
        ('Garfield is a cat.', ('tell', CONTINGENT)),
        ('Jon is a person.', ('tell', CONTINGENT)),
        ('Jon likes Garfield?', ('ask', CONTINGENT)),
    ]
    self.compareExtraCreditKnowledgeBase(examples, submission.createRule1)

  @graded(timeout=60, is_extra_credit=True)
  def test_4(self):
    """6a-4-basic:  Check basic behavior of rule"""
    examples = [
        ('Every person likes some cat.', ('tell', CONTINGENT)),
        ('Garfield is a cat.', ('tell', CONTINGENT)),
        ('Jon is a person.', ('tell', CONTINGENT)),
        ('Jon likes Garfield?', ('ask', CONTINGENT)),
    ]
    self.compareExtraCreditKnowledgeBase(examples, submission.createRule1)
class Test_6b(TestCase_A7):
  @graded(timeout=60, is_extra_credit=True)
  def test_0(self):
    """6b-0-basic:  Check basic behavior of rule"""
    examples = [
        ('There is some cat that every person likes.', ('tell', CONTINGENT)),
        ('Every cat is a mammal.', ('tell', CONTINGENT)),
        ('There is some mammal that every person likes?', ('ask', ENTAILMENT)),
    ]
    self.compareExtraCreditKnowledgeBase(examples, submission.createRule2)

  @graded(timeout=60, is_extra_credit=True)
  def test_1(self):
    """6b-1-basic:  Check basic behavior of rule"""
    examples = [
        ('There is some cat that every person likes.', ('tell', CONTINGENT)),
        ('Jon is a person.', ('tell', CONTINGENT)),
        ('Jon likes some cat?', ('ask', ENTAILMENT)),
    ]
    self.compareExtraCreditKnowledgeBase(examples, submission.createRule2)

  @graded(timeout=60, is_extra_credit=True)
  def test_2(self):
    """6b-2-basic:  Check basic behavior of rule"""
    examples = [
        ('There is some cat that every person likes.', ('tell', CONTINGENT)),
        ('Garfield is a cat.', ('tell', CONTINGENT)),
        ('Jon is a person.', ('tell', CONTINGENT)),
        ('Jon likes Garfield?', ('ask', CONTINGENT)),
    ]
    self.compareExtraCreditKnowledgeBase(examples, submission.createRule2)
class Test_6c(TestCase_A7):
  @graded(timeout=60, is_extra_credit = True)
  def test_0(self):
    """6c-0-basic:  Check basic behavior of rule"""
    examples = [
        ('If a person likes a cat then the former feeds the latter.', ('tell', CONTINGENT)),
        ('Jon is a person.', ('tell', CONTINGENT)),
        ('Jon likes Garfield.', ('tell', CONTINGENT)),
        ('Jon feeds Garfield?', ('ask', CONTINGENT)),
    ]
    self.compareExtraCreditKnowledgeBase(examples, submission.createRule3)

  @graded(timeout=60, is_extra_credit = True)
  def test_1(self):
    """6c-1-basic:  Check basic behavior of rule"""
    examples = [
        ('If a person likes a cat then the former feeds the latter.', ('tell', CONTINGENT)),
        ('Jon is a person.', ('tell', CONTINGENT)),
        ('Jon likes Garfield.', ('tell', CONTINGENT)),
        ('Garfield is a cat.', ('tell', CONTINGENT)),
        ('Jon feeds Garfield?', ('ask', ENTAILMENT)),
    ]
    self.compareExtraCreditKnowledgeBase(examples, submission.createRule3)

  @graded(timeout=60, is_extra_credit = True)
  def test_2(self):
    """6c-2-basic:  Check basic behavior of rule"""
    examples = [
        ('If a person likes a cat then the former feeds the latter.', ('tell', CONTINGENT)),
        ('Jon likes Garfield.', ('tell', CONTINGENT)),
        ('Garfield is a cat.', ('tell', CONTINGENT)),
        ('Jon feeds Garfield?', ('ask', CONTINGENT)),
    ]
    self.compareExtraCreditKnowledgeBase(examples, submission.createRule3)

  @graded(timeout=60, is_extra_credit = True)
  def test_3(self):
    """6c-3-basic:  Check basic behavior of rule"""
    examples = [
        ('If a person likes a cat then the former feeds the latter.', ('tell', CONTINGENT)),
        ('Jon is a person.', ('tell', CONTINGENT)),
        ('Jon likes some cat.', ('tell', CONTINGENT)),
        ('Garfield is a cat.', ('tell', CONTINGENT)),
        ('Jon feeds Garfield?', ('ask', CONTINGENT)),
    ]
    self.compareExtraCreditKnowledgeBase(examples, submission.createRule3)

def getTestCaseForTestID(test_id):
  question, part, _ = test_id.split('-')
  g = globals().copy()
  for name, obj in g.items():
    if inspect.isclass(obj) and name == ('Test_'+question):
      return obj('test_'+part)

if __name__ == '__main__':
  # Parse for a specific test
  parser = argparse.ArgumentParser()
  parser.add_argument('test_case', nargs='?', default='all')
  test_id = parser.parse_args().test_case

  assignment = unittest.TestSuite()
  if test_id != 'all':
    assignment.addTest(getTestCaseForTestID(test_id))
  else:
    assignment.addTests(unittest.defaultTestLoader.discover('.', pattern='grader.py'))
  CourseTestRunner().run(assignment)